# Landing Page Project

## description
landing page project built in html , css and js Manipulating the DOM exercise.

-i have built a  dynamic navigation menu as unordered list 
-when we click on any section it scrolls to this section smoothly 
-the selected section will be highlighted 

## author : Rana Osama Hassan

## tecs:
1.HTMLS
2.CSS3
3.ES6
 

