/**
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Define Variables
 * 
*/
let nav_menu = document.getElementById('navbar__list');
let sections = document.querySelectorAll('section');
//to reduce reflow
const fragment = document.createDocumentFragment();

/**
 * End Global Variable

*/

//function to build the navigation bar dynamically as an unordered list
function createNavList (){
//iterating on each section 
sections.forEach(function(section){
    const sectionName = section.getAttribute('data-nav')
    const sectionId = section.getAttribute('id');
    const listItem = document.createElement('li');
    //adding the content of each section to each a tag 
    listItem.innerHTML=`<a class='menu__link' href='#${sectionId}'>${sectionName}</a>`

    //smooth scrolling 
    listItem.addEventListener('click' ,function (e){
        e.preventDefault();
        section.scrollIntoView({
            behavior: 'smooth',

        });
    }); 
    nav_menu.appendChild(listItem);
  
});
//adding section to the nav bar
nav_menu.appendChild(fragment);
}
window.addEventListener('load',createNavList);




// active sections by adding class to each one 
window.addEventListener('scroll',function(){
   let sections = document.querySelectorAll('section');
    //iterating on each section 
    for (let section of sections ){
        const sectionTop  = section.getBoundingClientRect().top ;
        //getting the id of the current section 
        const activeLink = nav_menu.querySelector(`a[href='#${section.id}']`);
        if (sectionTop > -100 && sectionTop < 400){
            //adding active class 
            section.classList.add('your-active-class');
            //highlight the active section
            activeLink.classList.add('generate');


        } else {
            //removing active class 
            section.classList.remove('your-active-class');
            //removing highlight from inactive section
            activeLink.classList.remove('generate');
        }
    }
});

